package entities;

public enum CardType {
    SILVER, GOLD
}
